/*AUTHOR: HUSSEIN AHMED TEJAN
 * This Exception is thrown if the customer tries to book a new Service < 365 days or > 2 years from their last Service.
 */
package maintenancebookings;

/**
 *
 * @author LatinoWolofKid
 */
public                              class                   ExpiryServiceDateException              extends             Exception {
    
}
