/*AUTHOR: HUSSEIN AHMED TEJAN
 * This exception is thrown if the difference between the previous Mileage and the current Mileage <10,000 (min vehicle Mileage) or >12,000 (max vehicle Mileage).
 */
package maintenancebookings;


public                  class                           MileageException                extends                             Exception {

}
