/*AUTHOR: HUSSEIN AHMED TEJAN
 */
package maintenancebookings;

import java.util.ArrayList;

/**
 *
 * @author ht304
 */
public                                              interface                           ScheduledMaintenance {

    
    
//    Holidays holidates = new holi_public();
//    Holidays bankdates = new holi_bank();
    

//    ArrayList service=new <Service>ArrayList();
    
//    public static void main(String[] args) {
//       
//        
//        
//    }

}
