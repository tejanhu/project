/*AUTHOR: HUSSEIN AHMED TEJAN
*/
package maintenancebookings;

public                                          class                           MoT extends MaintenanceBooking {
//initialises the cost of all MoT to be £30

    public                                                                      MoT() {
        super(30);

    }
}
